import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    unoptimized: true, // allows local hero image without extra config
  },
};

export default nextConfig;
