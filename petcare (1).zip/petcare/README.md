# PetCare – Trusted Pet Sitting Marketplace

Mobile-first marketplace connecting pet owners with caregivers for dogs and cats.

## Features

- Pet owner care requests with location + search radius
- **Nearest Caregiver** search with server-side distance (Haversine)
- Sort by nearest / rating / price / experience
- Radius filters (5–50 km / any)
- Approximate location only (privacy-first)
- Caregiver profiles (volunteer / low-cost / professional)
- Digital care agreements (admin-configurable)
- Veterinarians directory + referral codes
- Pet services marketplace section
- Admin dashboard (stats, fees, users)
- Auth, pets, bookings, messaging structure

## Quick start

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Demo accounts

| Role      | Email                    | Password  |
|-----------|--------------------------|-----------|
| Owner     | owner@example.com        | owner123  |
| Caregiver | caregiver@example.com    | care123   |
| Admin     | admin@petcare.app        | admin123  |

## Tech

- Next.js (App Router) + TypeScript + Tailwind CSS
- File-based relational JSON database (`data/db.json`, auto-seeded)
- Server-side distance calculation
- Mobile-first responsive UI

## Notes

- GPS tracking architecture is prepared (optional)
- Payment system is configurable for future Stripe / local providers
- Terms & agreement templates state that final legal wording must comply with local law
- PetCare is a marketplace only and does not provide the care itself
