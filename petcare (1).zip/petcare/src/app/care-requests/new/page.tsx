'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

type Pet = {
  id: string;
  name: string;
  type: string;
  breed: string;
};

const RADIUS_OPTIONS = [
  { value: 5, label: '5 km' },
  { value: 10, label: '10 km' },
  { value: 25, label: '25 km' },
  { value: 50, label: '50 km' },
  { value: 0, label: 'Any distance' },
];

export default function NewCareRequestPage() {
  const router = useRouter();
  const [pets, setPets] = useState<Pet[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    petId: '',
    startDate: '',
    endDate: '',
    city: 'Berlin',
    location: '',
    searchRadiusKm: 25,
    specialInstructions: '',
    useCurrentLocation: false,
  });
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch('/api/pets');
        if (res.status === 401) {
          router.push('/auth/login');
          return;
        }
        const data = await res.json();
        setPets(data.pets || []);
        if (data.pets?.length) {
          setForm((f) => ({ ...f, petId: data.pets[0].id }));
        }
      } catch {
        setError('Could not load pets');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [router]);

  function useMyLocation() {
    if (!navigator.geolocation) {
      setError('Geolocation not supported');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setForm((f) => ({
          ...f,
          useCurrentLocation: true,
          location: 'Current location',
          city: 'Current location',
        }));
      },
      () => setError('Unable to get location')
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const res = await fetch('/api/care-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          latitude: coords?.lat,
          longitude: coords?.lng,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Failed to create request');
        return;
      }
      router.push('/bookings');
      router.refresh();
    } catch {
      setError('Something went wrong');
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return <div className="p-8 text-center text-gray-500">Loading…</div>;
  }

  if (pets.length === 0) {
    return (
      <div className="min-h-screen px-5 pt-12">
        <h1 className="text-xl font-bold mb-4">Create care request</h1>
        <p className="text-gray-600 mb-6">You need to add a pet first.</p>
        <Link href="/profile/pets/new" className="btn-primary">
          Add a pet
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 px-5 pt-8 pb-24">
      <Link href="/find-care" className="text-teal-600 text-sm font-medium mb-6 inline-block">
        ← Back
      </Link>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Create care request</h1>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="label">Pet</label>
          <select
            className="input"
            value={form.petId}
            onChange={(e) => setForm({ ...form, petId: e.target.value })}
            required
          >
            {pets.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.type} · {p.breed})
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Start date</label>
            <input
              type="date"
              className="input"
              value={form.startDate}
              onChange={(e) => setForm({ ...form, startDate: e.target.value })}
              required
            />
          </div>
          <div>
            <label className="label">End date</label>
            <input
              type="date"
              className="input"
              value={form.endDate}
              onChange={(e) => setForm({ ...form, endDate: e.target.value })}
              required
            />
          </div>
        </div>

        <div>
          <label className="label">Care location</label>
          <div className="flex gap-2 mb-2">
            <input
              className="input flex-1"
              placeholder="City or area"
              value={form.city}
              onChange={(e) =>
                setForm({ ...form, city: e.target.value, useCurrentLocation: false })
              }
              required
            />
            <button
              type="button"
              onClick={useMyLocation}
              className="btn-secondary px-3 text-xs whitespace-nowrap"
            >
              📍 Use my location
            </button>
          </div>
          <input
            className="input"
            placeholder="Additional details (optional)"
            value={form.location}
            onChange={(e) => setForm({ ...form, location: e.target.value })}
          />
          <p className="text-xs text-gray-500 mt-1.5">
            Your exact address is never shown publicly. Only approximate distance is shared.
          </p>
        </div>

        <div>
          <label className="label">Search radius</label>
          <select
            className="input"
            value={form.searchRadiusKm}
            onChange={(e) => setForm({ ...form, searchRadiusKm: Number(e.target.value) })}
          >
            {RADIUS_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <p className="text-xs text-gray-500 mt-1.5">
            Caregivers within this radius will be prioritized when sorted by nearest.
          </p>
        </div>

        <div>
          <label className="label">Special instructions (optional)</label>
          <textarea
            className="input min-h-[100px]"
            value={form.specialInstructions}
            onChange={(e) => setForm({ ...form, specialInstructions: e.target.value })}
            placeholder="Any extra notes for the caregiver…"
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 bg-red-50 rounded-xl px-4 py-3">{error}</div>
        )}

        <button type="submit" className="btn-primary w-full" disabled={submitting}>
          {submitting ? 'Creating…' : 'Create care request'}
        </button>
      </form>
    </div>
  );
}
