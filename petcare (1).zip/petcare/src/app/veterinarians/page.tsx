import { getDb } from '@/lib/db';
import Link from 'next/link';

export default async function VeterinariansPage() {
  const db = await getDb();
  const clinics = db.veterinaryClinics;

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      <header className="bg-white border-b border-gray-100 px-5 pt-8 pb-4">
        <h1 className="text-xl font-bold text-gray-900">Veterinarians</h1>
        <p className="text-sm text-gray-500 mt-1">Find clinics near you</p>
      </header>

      <div className="px-5 pt-5 space-y-3">
        {clinics.length === 0 ? (
          <div className="card text-center text-gray-500 py-8">No clinics listed yet.</div>
        ) : (
          clinics.map((c) => (
            <div key={c.id} className="card">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold text-gray-900">{c.name}</div>
                  {c.doctorName && (
                    <div className="text-sm text-gray-600">{c.doctorName}</div>
                  )}
                  <div className="text-xs text-gray-500 mt-1">{c.address}</div>
                  <div className="text-xs text-gray-500">{c.openingHours}</div>
                  <div className="flex gap-2 mt-2 flex-wrap">
                    {c.verified && <span className="badge-teal text-[10px]">Verified</span>}
                    {c.emergencyAvailable && (
                      <span className="badge-yellow text-[10px]">Emergency</span>
                    )}
                  </div>
                </div>
                <a
                  href={`tel:${c.phone}`}
                  className="btn-secondary text-xs px-3 py-2 shrink-0"
                >
                  Call
                </a>
              </div>
              <div className="mt-3 pt-3 border-t border-gray-50 text-xs text-gray-500">
                Referral code: <span className="font-mono font-medium text-teal-700">{c.referralCode}</span>
              </div>
            </div>
          ))
        )}

        <div className="card bg-teal-50 border-teal-100 mt-6">
          <div className="font-semibold text-teal-900 mb-1">Are you a veterinary clinic?</div>
          <p className="text-sm text-teal-800 mb-3">
            Join PetCare, get a unique QR code for your reception and track referrals.
          </p>
          <Link href="/auth/register" className="text-sm font-semibold text-teal-700">
            Register your clinic →
          </Link>
        </div>
      </div>
    </div>
  );
}
