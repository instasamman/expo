'use client';

import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';

type Caregiver = {
  id: string;
  userId: string;
  name: string;
  city: string;
  locationLabel: string;
  distanceKm: number | null;
  distanceLabel: string;
  rating: number;
  reviewCount: number;
  completedBookings: number;
  priceType: string;
  pricePerDay: number;
  currency: string;
  acceptsDogs: boolean;
  acceptsCats: boolean;
  maxPets: number;
  identityVerified: boolean;
  verified: boolean;
  bio?: string;
  experience: string;
};

const RADIUS_OPTIONS = [
  { value: 5, label: '5 km' },
  { value: 10, label: '10 km' },
  { value: 25, label: '25 km' },
  { value: 50, label: '50 km' },
  { value: 0, label: 'Any distance' },
];

const SORT_OPTIONS = [
  { value: 'nearest', label: 'Nearest' },
  { value: 'rating', label: 'Highest rated' },
  { value: 'price_low', label: 'Lowest price' },
  { value: 'price_high', label: 'Highest price' },
  { value: 'experienced', label: 'Most experienced' },
];

export default function FindCarePage() {
  const [caregivers, setCaregivers] = useState<Caregiver[]>([]);
  const [loading, setLoading] = useState(true);
  const [city, setCity] = useState('Berlin');
  const [lat, setLat] = useState<number | null>(52.52);
  const [lng, setLng] = useState<number | null>(13.405);
  const [radius, setRadius] = useState(25);
  const [petType, setPetType] = useState('');
  const [priceType, setPriceType] = useState('');
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [sort, setSort] = useState('nearest');
  const [usingGeo, setUsingGeo] = useState(false);
  const [geoError, setGeoError] = useState('');

  const fetchCaregivers = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (lat != null && lng != null) {
        params.set('lat', String(lat));
        params.set('lng', String(lng));
      }
      if (city) params.set('city', city);
      params.set('radius', String(radius));
      if (petType) params.set('petType', petType);
      if (priceType) params.set('priceType', priceType);
      if (verifiedOnly) params.set('verified', 'true');
      params.set('sort', sort);

      const res = await fetch(`/api/caregivers?${params.toString()}`);
      const data = await res.json();
      setCaregivers(data.caregivers || []);
    } catch {
      setCaregivers([]);
    } finally {
      setLoading(false);
    }
  }, [lat, lng, city, radius, petType, priceType, verifiedOnly, sort]);

  useEffect(() => {
    fetchCaregivers();
  }, [fetchCaregivers]);

  function useMyLocation() {
    setGeoError('');
    if (!navigator.geolocation) {
      setGeoError('Geolocation is not supported by your browser');
      return;
    }
    setUsingGeo(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLat(pos.coords.latitude);
        setLng(pos.coords.longitude);
        setCity('Current location');
        setUsingGeo(false);
      },
      () => {
        setGeoError('Unable to get your location. Please enter a city.');
        setUsingGeo(false);
      },
      { enableHighAccuracy: false, timeout: 10000 }
    );
  }

  function priceLabel(c: Caregiver) {
    if (c.priceType === 'volunteer' || c.pricePerDay === 0) return 'Volunteer';
    return `€${c.pricePerDay}/day`;
  }

  function petsLabel(c: Caregiver) {
    const parts = [];
    if (c.acceptsDogs) parts.push('Dogs');
    if (c.acceptsCats) parts.push('Cats');
    return parts.join(' & ') || 'Pets';
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      <header className="sticky top-0 z-40 bg-white border-b border-gray-100 px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-xl font-bold text-gray-900">Find Care</h1>
          <Link href="/care-requests/new" className="text-sm font-semibold text-teal-600">
            + Request
          </Link>
        </div>

        {/* Location */}
        <div className="flex gap-2 mb-3">
          <input
            className="input flex-1 text-sm py-2.5"
            placeholder="City or area"
            value={city}
            onChange={(e) => {
              setCity(e.target.value);
              // Reset to city approx when typing
              if (e.target.value.toLowerCase().includes('berlin')) {
                setLat(52.52);
                setLng(13.405);
              }
            }}
          />
          <button
            type="button"
            onClick={useMyLocation}
            disabled={usingGeo}
            className="btn-secondary px-3 py-2.5 text-xs whitespace-nowrap"
          >
            {usingGeo ? '…' : '📍 Near me'}
          </button>
        </div>
        {geoError && <p className="text-xs text-red-600 mb-2">{geoError}</p>}

        {/* Radius & Sort */}
        <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
          <select
            className="input text-xs py-2 w-auto min-w-[110px]"
            value={radius}
            onChange={(e) => setRadius(Number(e.target.value))}
          >
            {RADIUS_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <select
            className="input text-xs py-2 w-auto min-w-[130px]"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            {SORT_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <select
            className="input text-xs py-2 w-auto"
            value={petType}
            onChange={(e) => setPetType(e.target.value)}
          >
            <option value="">Any pet</option>
            <option value="dog">Dogs</option>
            <option value="cat">Cats</option>
          </select>
          <select
            className="input text-xs py-2 w-auto"
            value={priceType}
            onChange={(e) => setPriceType(e.target.value)}
          >
            <option value="">Any price</option>
            <option value="volunteer">Volunteer</option>
            <option value="lowcost">Low-cost</option>
            <option value="professional">Professional</option>
          </select>
          <label className="flex items-center gap-1.5 text-xs whitespace-nowrap px-2">
            <input
              type="checkbox"
              checked={verifiedOnly}
              onChange={(e) => setVerifiedOnly(e.target.checked)}
              className="rounded"
            />
            Verified
          </label>
        </div>
      </header>

      <div className="px-4 pt-4">
        {loading ? (
          <div className="text-center py-12 text-gray-500">Loading caregivers…</div>
        ) : caregivers.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-4xl mb-3">🐾</div>
            <p className="text-gray-600 font-medium">No caregivers found</p>
            <p className="text-sm text-gray-500 mt-1">Try increasing the radius or changing filters</p>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-xs text-gray-500 mb-2">
              {caregivers.length} caregiver{caregivers.length !== 1 ? 's' : ''} · sorted by{' '}
              {SORT_OPTIONS.find((s) => s.value === sort)?.label.toLowerCase()}
            </p>
            {caregivers.map((c) => (
              <Link
                key={c.id}
                href={`/caregivers/${c.userId}`}
                className="card block active:scale-[0.99] transition"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-gray-900">{c.name}</span>
                      {c.verified && (
                        <span className="badge-teal text-[10px]">Verified</span>
                      )}
                    </div>
                    <div className="text-sm text-teal-700 font-medium mt-0.5">
                      {c.distanceLabel}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {petsLabel(c)} accepted · Max {c.maxPets} pet{c.maxPets > 1 ? 's' : ''}
                    </div>
                    <div className="flex items-center gap-2 mt-2 text-xs text-gray-600">
                      <span>⭐ {c.rating.toFixed(1)}</span>
                      <span>·</span>
                      <span>{c.reviewCount} reviews</span>
                      <span>·</span>
                      <span>{c.completedBookings} stays</span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-semibold text-gray-900 text-sm">{priceLabel(c)}</div>
                    <div className="text-[10px] text-gray-400 mt-0.5 capitalize">{c.priceType}</div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
