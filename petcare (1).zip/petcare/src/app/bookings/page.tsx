import Link from 'next/link';
import { getCurrentUser } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { redirect } from 'next/navigation';

export default async function BookingsPage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect('/auth/login');
  }

  const db = await getDb();
  const myBookings = db.bookings.filter(
    (b) => b.ownerId === user.id || b.caregiverId === user.id
  );
  const myRequests = db.careRequests.filter((r) => r.ownerId === user.id);

  // Enrich
  const bookingsEnriched = myBookings.map((b) => {
    const pet = db.pets.find((p) => p.id === b.petId);
    const otherId = b.ownerId === user.id ? b.caregiverId : b.ownerId;
    const other = db.users.find((u) => u.id === otherId);
    return {
      ...b,
      petName: pet?.name,
      otherName: other?.name,
      isOwner: b.ownerId === user.id,
    };
  });

  const requestsEnriched = myRequests.map((r) => {
    const pet = db.pets.find((p) => p.id === r.petId);
    const offers = db.careOffers.filter((o) => o.careRequestId === r.id);
    return {
      ...r,
      petName: pet?.name,
      petType: pet?.type,
      offerCount: offers.length,
    };
  });

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      <header className="bg-white border-b border-gray-100 px-5 pt-8 pb-4">
        <h1 className="text-xl font-bold text-gray-900">Bookings</h1>
      </header>

      <div className="px-5 pt-5 space-y-6">
        {/* Active care requests */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold text-gray-900">My care requests</h2>
            <Link href="/care-requests/new" className="text-sm font-semibold text-teal-600">
              + New
            </Link>
          </div>
          {requestsEnriched.length === 0 ? (
            <div className="card text-center text-sm text-gray-500 py-6">
              No care requests yet.
            </div>
          ) : (
            <div className="space-y-2">
              {requestsEnriched.map((r) => (
                <Link
                  key={r.id}
                  href={`/care-requests/${r.id}`}
                  className="card block"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-semibold">
                        {r.petName} ({r.petType})
                      </div>
                      <div className="text-xs text-gray-500 mt-0.5">
                        {r.startDate} → {r.endDate} · {r.city}
                      </div>
                      <div className="text-xs text-teal-600 mt-1">
                        {r.offerCount} offer{r.offerCount !== 1 ? 's' : ''}
                      </div>
                    </div>
                    <span className="badge-gray capitalize text-[10px]">{r.status}</span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </section>

        {/* Bookings */}
        <section>
          <h2 className="font-bold text-gray-900 mb-3">Confirmed bookings</h2>
          {bookingsEnriched.length === 0 ? (
            <div className="card text-center text-sm text-gray-500 py-6">
              No bookings yet.
            </div>
          ) : (
            <div className="space-y-2">
              {bookingsEnriched.map((b) => (
                <Link key={b.id} href={`/bookings/${b.id}`} className="card block">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-semibold">{b.petName}</div>
                      <div className="text-xs text-gray-500 mt-0.5">
                        with {b.otherName} · {b.startDate} → {b.endDate}
                      </div>
                      <div className="text-xs mt-1">
                        {b.agreedPrice > 0 ? `€${b.agreedPrice}` : 'Volunteer'} ·{' '}
                        {b.isOwner ? 'You are the owner' : 'You are the caregiver'}
                      </div>
                    </div>
                    <span
                      className={`text-[10px] badge ${
                        b.status === 'active'
                          ? 'badge-green'
                          : b.status === 'completed'
                          ? 'badge-gray'
                          : 'badge-yellow'
                      } capitalize`}
                    >
                      {b.status.replace('_', ' ')}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
