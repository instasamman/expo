import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb, saveDb, generateId, createNotification, approxCoordsForCity } from '@/lib/db';
import { CareRequest } from '@/lib/types';

export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    const { searchParams } = new URL(req.url);
    const mine = searchParams.get('mine') === 'true';
    const status = searchParams.get('status');

    const db = await getDb();
    let requests = db.careRequests;

    if (mine && user) {
      requests = requests.filter((r) => r.ownerId === user.id);
    } else {
      requests = requests.filter((r) => r.status === 'open' || r.status === 'offered');
    }
    if (status) {
      requests = requests.filter((r) => r.status === status);
    }

    // Enrich with pet + owner name
    const enriched = requests.map((r) => {
      const pet = db.pets.find((p) => p.id === r.petId);
      const owner = db.users.find((u) => u.id === r.ownerId);
      return {
        ...r,
        petName: pet?.name,
        petType: pet?.type,
        petBreed: pet?.breed,
        ownerName: owner?.name,
      };
    });

    return NextResponse.json({ requests: enriched });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const {
      petId,
      startDate,
      endDate,
      location,
      city,
      latitude,
      longitude,
      searchRadiusKm = 25,
      specialInstructions,
    } = body;

    if (!petId || !startDate || !endDate || !city) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const db = await getDb();
    const pet = db.pets.find((p) => p.id === petId && p.ownerId === user.id);
    if (!pet) {
      return NextResponse.json({ error: 'Pet not found' }, { status: 404 });
    }

    let lat = latitude;
    let lng = longitude;
    if ((lat == null || lng == null) && city) {
      const coords = approxCoordsForCity(city);
      if (coords) {
        lat = coords.lat;
        lng = coords.lng;
      }
    }

    const request: CareRequest = {
      id: generateId(),
      ownerId: user.id,
      petId,
      startDate,
      endDate,
      location: location || city,
      city,
      latitude: lat,
      longitude: lng,
      searchRadiusKm: Number(searchRadiusKm) || 25,
      specialInstructions,
      status: 'open',
      createdAt: new Date().toISOString(),
    };

    db.careRequests.push(request);
    await saveDb(db);

    // Notify caregivers in the area (simplified: all caregivers for now)
    for (const profile of db.caregiverProfiles) {
      if (
        (pet.type === 'dog' && profile.acceptsDogs) ||
        (pet.type === 'cat' && profile.acceptsCats)
      ) {
        await createNotification(
          profile.userId,
          'new_care_request',
          'New care request nearby',
          `${pet.name} (${pet.type}) needs care from ${startDate} to ${endDate} in ${city}`,
          { careRequestId: request.id }
        );
      }
    }

    return NextResponse.json({ success: true, request });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
