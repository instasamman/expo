import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb, saveDb, generateId, getPetsByOwner } from '@/lib/db';
import { Pet } from '@/lib/types';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const pets = await getPetsByOwner(user.id);
    return NextResponse.json({ pets });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const body = await req.json();
    const {
      name,
      type,
      age,
      breed,
      gender,
      medicalInfo,
      behaviourInfo,
      foodInstructions,
      specialInstructions,
    } = body;

    if (!name || !type || age == null || !breed || !gender) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const db = await getDb();
    const pet: Pet = {
      id: generateId(),
      ownerId: user.id,
      name,
      type,
      age: Number(age),
      breed,
      gender,
      medicalInfo,
      behaviourInfo,
      foodInstructions,
      specialInstructions,
      createdAt: new Date().toISOString(),
    };
    db.pets.push(pet);
    await saveDb(db);
    return NextResponse.json({ success: true, pet });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
