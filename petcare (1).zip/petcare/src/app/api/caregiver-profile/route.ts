import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb, saveDb, generateId, getCaregiverProfile, approxCoordsForCity } from '@/lib/db';
import { CaregiverProfile } from '@/lib/types';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const profile = await getCaregiverProfile(user.id);
    return NextResponse.json({ profile: profile || null });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    if (!user.role.includes('caregiver') && !user.role.includes('owner')) {
      // Allow any logged-in user to become caregiver
    }

    const body = await req.json();
    const {
      bio,
      experience,
      acceptsDogs,
      acceptsCats,
      maxPets,
      homeEnvironment,
      priceType,
      pricePerDay,
      city,
      location,
    } = body;

    if (!experience || !city) {
      return NextResponse.json({ error: 'Experience and city are required' }, { status: 400 });
    }

    const db = await getDb();
    let profile = db.caregiverProfiles.find((p) => p.userId === user.id);
    const coords = approxCoordsForCity(city) || approxCoordsForCity(location || '');

    if (profile) {
      profile.bio = bio;
      profile.experience = experience;
      profile.acceptsDogs = !!acceptsDogs;
      profile.acceptsCats = !!acceptsCats;
      profile.maxPets = Number(maxPets) || 1;
      profile.homeEnvironment = homeEnvironment;
      profile.priceType = priceType || 'lowcost';
      profile.pricePerDay = priceType === 'volunteer' ? 0 : Number(pricePerDay) || 0;
      profile.city = city;
      profile.location = location || city;
      if (coords) {
        profile.latitude = coords.lat;
        profile.longitude = coords.lng;
      }
      profile.locationVisibility = 'approximate';
    } else {
      profile = {
        id: generateId(),
        userId: user.id,
        bio,
        experience,
        acceptsDogs: !!acceptsDogs,
        acceptsCats: !!acceptsCats,
        maxPets: Number(maxPets) || 1,
        homeEnvironment,
        priceType: priceType || 'lowcost',
        pricePerDay: priceType === 'volunteer' ? 0 : Number(pricePerDay) || 0,
        currency: 'EUR',
        availability: [],
        rating: 0,
        reviewCount: 0,
        completedBookings: 0,
        identityVerified: false,
        location: location || city,
        city,
        latitude: coords?.lat,
        longitude: coords?.lng,
        locationVisibility: 'approximate',
        searchRadiusKm: 25,
        createdAt: new Date().toISOString(),
      };
      db.caregiverProfiles.push(profile);

      // Ensure caregiver role
      if (!user.role.includes('caregiver')) {
        const u = db.users.find((x) => x.id === user.id);
        if (u) u.role.push('caregiver');
      }
    }

    await saveDb(db);
    return NextResponse.json({ success: true, profile });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
