import { NextRequest, NextResponse } from 'next/server';
import { register } from '@/lib/auth';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password, name, phone, city, roles } = body;
    if (!email || !password || !name || !roles?.length) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }
    const result = await register({ email, password, name, phone, city, roles });
    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 400 });
    }
    return NextResponse.json({
      success: true,
      user: {
        id: result.user!.id,
        name: result.user!.name,
        email: result.user!.email,
        role: result.user!.role,
      },
    });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
