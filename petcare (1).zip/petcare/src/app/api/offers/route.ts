import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb, saveDb, generateId, createNotification } from '@/lib/db';
import { CareOffer } from '@/lib/types';

export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const careRequestId = searchParams.get('careRequestId');

    const db = await getDb();
    let offers = db.careOffers;

    if (careRequestId) {
      offers = offers.filter((o) => o.careRequestId === careRequestId);
    } else {
      // My offers as caregiver
      offers = offers.filter((o) => o.caregiverId === user.id);
    }

    const enriched = offers.map((o) => {
      const caregiver = db.users.find((u) => u.id === o.caregiverId);
      const profile = db.caregiverProfiles.find((p) => p.userId === o.caregiverId);
      return {
        ...o,
        caregiverName: caregiver?.name,
        rating: profile?.rating,
        verified: profile?.identityVerified || caregiver?.verified,
      };
    });

    return NextResponse.json({ offers: enriched });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { careRequestId, message, pricePerDay, priceType } = body;

    if (!careRequestId) {
      return NextResponse.json({ error: 'careRequestId required' }, { status: 400 });
    }

    const db = await getDb();
    const request = db.careRequests.find((r) => r.id === careRequestId);
    if (!request || (request.status !== 'open' && request.status !== 'offered')) {
      return NextResponse.json({ error: 'Request not available' }, { status: 400 });
    }

    const profile = db.caregiverProfiles.find((p) => p.userId === user.id);
    if (!profile) {
      return NextResponse.json({ error: 'Complete caregiver profile first' }, { status: 400 });
    }

    // Prevent duplicate offer
    if (db.careOffers.some((o) => o.careRequestId === careRequestId && o.caregiverId === user.id && o.status === 'pending')) {
      return NextResponse.json({ error: 'You already sent an offer' }, { status: 400 });
    }

    const offer: CareOffer = {
      id: generateId(),
      careRequestId,
      caregiverId: user.id,
      message,
      pricePerDay: Number(pricePerDay) ?? profile.pricePerDay ?? 0,
      priceType: priceType || profile.priceType,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    db.careOffers.push(offer);
    if (request.status === 'open') request.status = 'offered';
    await saveDb(db);

    await createNotification(
      request.ownerId,
      'new_offer',
      'New caregiver offer',
      `${user.name} offered to care for your pet`,
      { careRequestId, offerId: offer.id }
    );

    return NextResponse.json({ success: true, offer });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
