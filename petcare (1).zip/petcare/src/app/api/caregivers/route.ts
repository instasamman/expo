import { NextRequest, NextResponse } from 'next/server';
import { getDb, distanceKm, formatDistance, approxCoordsForCity } from '@/lib/db';
import { CaregiverProfile, User } from '@/lib/types';

export type CaregiverResult = {
  id: string;
  userId: string;
  name: string;
  city: string;
  locationLabel: string;
  distanceKm: number | null;
  distanceLabel: string;
  rating: number;
  reviewCount: number;
  completedBookings: number;
  priceType: string;
  pricePerDay: number;
  currency: string;
  acceptsDogs: boolean;
  acceptsCats: boolean;
  maxPets: number;
  identityVerified: boolean;
  verified: boolean;
  bio?: string;
  experience: string;
  latitude?: number;
  longitude?: number;
};

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const lat = parseFloat(searchParams.get('lat') || '');
    const lng = parseFloat(searchParams.get('lng') || '');
    const city = searchParams.get('city') || '';
    const radiusKm = parseFloat(searchParams.get('radius') || '0'); // 0 = any
    const petType = searchParams.get('petType') || ''; // dog | cat
    const priceType = searchParams.get('priceType') || ''; // volunteer | lowcost | professional
    const verifiedOnly = searchParams.get('verified') === 'true';
    const sort = searchParams.get('sort') || 'nearest'; // nearest | rating | price_low | price_high | experienced

    const db = await getDb();

    let originLat = isNaN(lat) ? undefined : lat;
    let originLng = isNaN(lng) ? undefined : lng;

    // Fallback to city approx if no coords
    if ((originLat === undefined || originLng === undefined) && city) {
      const coords = approxCoordsForCity(city);
      if (coords) {
        originLat = coords.lat;
        originLng = coords.lng;
      }
    }

    const results: CaregiverResult[] = [];

    for (const profile of db.caregiverProfiles) {
      const user = db.users.find((u) => u.id === profile.userId);
      if (!user) continue;

      // Pet type filter
      if (petType === 'dog' && !profile.acceptsDogs) continue;
      if (petType === 'cat' && !profile.acceptsCats) continue;

      // Price type
      if (priceType && profile.priceType !== priceType) continue;

      // Verified
      if (verifiedOnly && !(profile.identityVerified || user.verified)) continue;

      let dist: number | null = null;
      if (
        originLat !== undefined &&
        originLng !== undefined &&
        profile.latitude != null &&
        profile.longitude != null
      ) {
        dist = distanceKm(originLat, originLng, profile.latitude, profile.longitude);
      }

      // Radius filter (only if we have distance)
      if (radiusKm > 0 && dist !== null && dist > radiusKm) continue;

      results.push({
        id: profile.id,
        userId: profile.userId,
        name: user.name,
        city: profile.city,
        locationLabel: profile.location, // approximate public label only
        distanceKm: dist,
        distanceLabel: dist !== null ? formatDistance(dist) : profile.city,
        rating: profile.rating,
        reviewCount: profile.reviewCount,
        completedBookings: profile.completedBookings,
        priceType: profile.priceType,
        pricePerDay: profile.pricePerDay ?? 0,
        currency: profile.currency,
        acceptsDogs: profile.acceptsDogs,
        acceptsCats: profile.acceptsCats,
        maxPets: profile.maxPets,
        identityVerified: profile.identityVerified,
        verified: user.verified || profile.identityVerified,
        bio: profile.bio,
        experience: profile.experience,
        // Only expose approximate coords for map (already approximate)
        latitude: profile.latitude,
        longitude: profile.longitude,
      });
    }

    // Sort
    results.sort((a, b) => {
      switch (sort) {
        case 'nearest':
          if (a.distanceKm == null && b.distanceKm == null) return 0;
          if (a.distanceKm == null) return 1;
          if (b.distanceKm == null) return -1;
          return a.distanceKm - b.distanceKm;
        case 'rating':
          return b.rating - a.rating;
        case 'price_low':
          return a.pricePerDay - b.pricePerDay;
        case 'price_high':
          return b.pricePerDay - a.pricePerDay;
        case 'experienced':
          return b.completedBookings - a.completedBookings;
        default:
          return 0;
      }
    });

    return NextResponse.json({
      caregivers: results,
      origin: originLat != null ? { lat: originLat, lng: originLng } : null,
      count: results.length,
    });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
