import Link from 'next/link';

const CATEGORIES = [
  { id: 'grooming', label: 'Mobile grooming', icon: '✂️' },
  { id: 'washing', label: 'Pet washing', icon: '🛁' },
  { id: 'cleaning', label: 'Pet cleaning', icon: '✨' },
  { id: 'transport', label: 'Pet transport', icon: '🚗' },
  { id: 'training', label: 'Training', icon: '🎓' },
  { id: 'veterinary', label: 'Veterinary services', icon: '🩺' },
  { id: 'other', label: 'Other services', icon: '🐾' },
];

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      <header className="bg-white border-b border-gray-100 px-5 pt-8 pb-4">
        <h1 className="text-xl font-bold text-gray-900">Pet Services</h1>
        <p className="text-sm text-gray-500 mt-1">Grooming, transport, training and more</p>
      </header>

      <div className="px-5 pt-5 space-y-3">
        {CATEGORIES.map((c) => (
          <div key={c.id} className="card flex items-center gap-4">
            <div className="text-2xl">{c.icon}</div>
            <div className="flex-1">
              <div className="font-semibold text-gray-900">{c.label}</div>
              <div className="text-xs text-gray-500">Coming soon — providers can join</div>
            </div>
            <span className="text-gray-300">→</span>
          </div>
        ))}

        <div className="pt-4">
          <Link href="/offer-care" className="btn-secondary w-full text-center block">
            Offer a pet service
          </Link>
        </div>
      </div>
    </div>
  );
}
