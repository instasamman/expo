import { getCurrentUser } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { redirect } from 'next/navigation';
import Link from 'next/link';

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user || !user.role.includes('admin')) {
    redirect('/');
  }

  const db = await getDb();
  const settings = db.adminSettings[0];

  const stats = {
    users: db.users.length,
    owners: db.users.filter((u) => u.role.includes('owner')).length,
    caregivers: db.caregiverProfiles.length,
    clinics: db.veterinaryClinics.length,
    serviceProviders: db.serviceProviders.length,
    activeBookings: db.bookings.filter((b) => b.status === 'active').length,
    completedBookings: db.bookings.filter((b) => b.status === 'completed').length,
    cancelledBookings: db.bookings.filter((b) => b.status === 'cancelled').length,
    openRequests: db.careRequests.filter((r) => r.status === 'open' || r.status === 'offered').length,
    reports: db.reports.filter((r) => r.status === 'open').length,
    verifications: db.verificationRequests.filter((v) => v.status === 'pending').length,
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      <header className="bg-white border-b border-gray-100 px-5 pt-8 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-sm text-gray-500">PetCare platform overview</p>
          </div>
          <Link href="/" className="text-sm text-teal-600 font-medium">
            ← App
          </Link>
        </div>
      </header>

      <div className="px-5 pt-5 space-y-6">
        {/* Stats grid */}
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: 'Total users', value: stats.users },
            { label: 'Pet owners', value: stats.owners },
            { label: 'Caregivers', value: stats.caregivers },
            { label: 'Vet clinics', value: stats.clinics },
            { label: 'Open requests', value: stats.openRequests },
            { label: 'Active bookings', value: stats.activeBookings },
            { label: 'Completed', value: stats.completedBookings },
            { label: 'Cancelled', value: stats.cancelledBookings },
            { label: 'Open reports', value: stats.reports },
            { label: 'Pending verifications', value: stats.verifications },
          ].map((s) => (
            <div key={s.label} className="card py-4 text-center">
              <div className="text-2xl font-bold text-gray-900">{s.value}</div>
              <div className="text-xs text-gray-500 mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Fee settings */}
        <section className="card">
          <h2 className="font-bold text-gray-900 mb-3">Service fees (configurable)</h2>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Owner fee</span>
              <span className="font-medium">{settings?.serviceFeeOwnerPercent ?? 10}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Caregiver fee</span>
              <span className="font-medium">{settings?.serviceFeeCaregiverPercent ?? 5}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Fixed fee</span>
              <span className="font-medium">
                {settings?.serviceFeeFixed ?? 0} {settings?.currency ?? 'EUR'}
              </span>
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-3">
            Fees are transparent and configurable. Payment provider integration is prepared for future Stripe / local providers.
          </p>
        </section>

        {/* Users list (simple) */}
        <section>
          <h2 className="font-bold text-gray-900 mb-3">Recent users</h2>
          <div className="space-y-2">
            {db.users.slice(0, 10).map((u) => (
              <div key={u.id} className="card flex items-center justify-between py-3">
                <div>
                  <div className="font-medium text-sm">{u.name}</div>
                  <div className="text-xs text-gray-500">{u.email}</div>
                </div>
                <div className="flex gap-1">
                  {u.role.map((r) => (
                    <span key={r} className="badge-gray text-[10px] capitalize">
                      {r}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="card bg-teal-50 border-teal-100">
          <h2 className="font-bold text-teal-900 mb-1">Terms & agreements</h2>
          <p className="text-sm text-teal-800">
            Legal agreement templates and terms are managed here. Final wording must comply with local law. PetCare does not provide care and makes no liability claims beyond the platform role.
          </p>
        </section>
      </div>
    </div>
  );
}
