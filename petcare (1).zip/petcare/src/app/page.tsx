'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import { translations, Lang } from '@/lib/i18n';

export default function HomePage() {
  const [lang, setLang] = useState<Lang>('en');
  const [userName, setUserName] = useState<string | null>(null);

  useEffect(() => {
    // Persist language
    const saved = localStorage.getItem('petcare_lang') as Lang | null;
    if (saved === 'en' || saved === 'ar') setLang(saved);

    // Check session via a lightweight call (optional)
    fetch('/api/auth/me')
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.user?.name) setUserName(d.user.name.split(' ')[0]);
      })
      .catch(() => {});
  }, []);

  function changeLang(l: Lang) {
    setLang(l);
    localStorage.setItem('petcare_lang', l);
    document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = l;
  }

  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  const t = translations[lang];

  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-50 to-white">
      {/* Header */}
      <header className="px-5 pt-8 pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-teal-600 flex items-center justify-center text-white text-xl font-bold">
              P
            </div>
            <span className="text-xl font-bold text-gray-900">{t.appName}</span>
          </div>
          <div className="flex items-center gap-3">
            <LanguageSwitcher lang={lang} onChange={changeLang} />
            {userName ? (
              <Link href="/profile" className="text-sm font-medium text-teal-700">
                {t.hi}, {userName}
              </Link>
            ) : (
              <Link href="/auth/login" className="text-sm font-medium text-teal-700">
                {t.signIn}
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Hero Image – dog & cat like the reference photo */}
      <section className="px-5 pt-2">
        <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden shadow-md bg-gray-100">
          <Image
            src="/hero-pets.jpg"
            alt="Golden Retriever and gray cat resting together on a sofa"
            fill
            className="object-cover"
            priority
            sizes="(max-width: 768px) 100vw, 600px"
          />
        </div>
      </section>

      {/* Hero text */}
      <section className="px-5 pt-5 pb-8">
        <h1 className="text-3xl font-bold text-gray-900 leading-tight mb-3">
          {t.tagline}
        </h1>
        <p className="text-gray-600 text-base mb-6">{t.subtitle}</p>

        <div className="grid grid-cols-2 gap-3">
          <Link
            href="/find-care"
            className="col-span-2 flex items-center justify-center gap-2 rounded-2xl bg-teal-600 text-white py-4 text-base font-semibold shadow-lg shadow-teal-600/20 active:scale-[0.98] transition"
          >
            🔍 {t.findCare}
          </Link>
          <Link
            href="/offer-care"
            className="flex items-center justify-center gap-2 rounded-2xl bg-white border border-teal-100 text-teal-800 py-3.5 text-sm font-semibold shadow-sm active:scale-[0.98] transition"
          >
            🐾 {t.offerCare}
          </Link>
          <Link
            href="/services"
            className="flex items-center justify-center gap-2 rounded-2xl bg-white border border-teal-100 text-teal-800 py-3.5 text-sm font-semibold shadow-sm active:scale-[0.98] transition"
          >
            ✂️ {t.petServices}
          </Link>
          <Link
            href="/veterinarians"
            className="col-span-2 flex items-center justify-center gap-2 rounded-2xl bg-white border border-teal-100 text-teal-800 py-3.5 text-sm font-semibold shadow-sm active:scale-[0.98] transition"
          >
            🏥 {t.findVet}
          </Link>
        </div>
      </section>

      {/* Trust badges */}
      <section className="px-5 py-6">
        <div className="grid grid-cols-3 gap-3 text-center">
          <div className="card py-4">
            <div className="text-2xl mb-1">✅</div>
            <div className="text-xs font-medium text-gray-700">{t.verifiedProfiles}</div>
          </div>
          <div className="card py-4">
            <div className="text-2xl mb-1">⭐</div>
            <div className="text-xs font-medium text-gray-700">{t.ratingsReviews}</div>
          </div>
          <div className="card py-4">
            <div className="text-2xl mb-1">🛡️</div>
            <div className="text-xs font-medium text-gray-700">{t.digitalAgreements}</div>
          </div>
        </div>
      </section>

      {/* Caregivers Near You */}
      <section className="px-5 py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-gray-900">{t.caregiversNearYou}</h2>
          <Link href="/find-care" className="text-sm font-semibold text-teal-600">
            {t.viewAll}
          </Link>
        </div>
        <Link
          href="/find-care"
          className="card flex items-center justify-between active:scale-[0.99] transition"
        >
          <div>
            <div className="font-semibold text-gray-900">{t.viewNearby}</div>
            <div className="text-sm text-gray-500 mt-0.5">{t.viewNearbyDesc}</div>
          </div>
          <div className="text-2xl">📍</div>
        </Link>
      </section>

      {/* How it works */}
      <section className="px-5 py-6">
        <h2 className="text-lg font-bold text-gray-900 mb-4">{t.howItWorks}</h2>
        <div className="space-y-4">
          {[
            { step: '1', title: t.step1Title, desc: t.step1Desc },
            { step: '2', title: t.step2Title, desc: t.step2Desc },
            { step: '3', title: t.step3Title, desc: t.step3Desc },
            { step: '4', title: t.step4Title, desc: t.step4Desc },
          ].map((item) => (
            <div key={item.step} className="flex gap-4 items-start">
              <div className="w-8 h-8 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center text-sm font-bold shrink-0">
                {item.step}
              </div>
              <div>
                <div className="font-semibold text-gray-900">{item.title}</div>
                <div className="text-sm text-gray-500">{item.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Care options */}
      <section className="px-5 py-6 pb-12">
        <h2 className="text-lg font-bold text-gray-900 mb-4">{t.careOptions}</h2>
        <div className="space-y-3">
          <div className="card flex items-center gap-4">
            <div className="text-2xl">💚</div>
            <div>
              <div className="font-semibold">{t.volunteer}</div>
              <div className="text-sm text-gray-500">{t.volunteerDesc}</div>
            </div>
          </div>
          <div className="card flex items-center gap-4">
            <div className="text-2xl">💰</div>
            <div>
              <div className="font-semibold">{t.lowCost}</div>
              <div className="text-sm text-gray-500">{t.lowCostDesc}</div>
            </div>
          </div>
          <div className="card flex items-center gap-4">
            <div className="text-2xl">⭐</div>
            <div>
              <div className="font-semibold">{t.professional}</div>
              <div className="text-sm text-gray-500">{t.professionalDesc}</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
