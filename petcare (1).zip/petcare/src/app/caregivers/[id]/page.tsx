import { getDb, distanceKm, formatDistance } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import Link from 'next/link';
import { notFound } from 'next/navigation';

export default async function CaregiverDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const db = await getDb();
  const user = db.users.find((u) => u.id === id);
  const profile = db.caregiverProfiles.find((p) => p.userId === id);

  if (!user || !profile) {
    notFound();
  }

  const currentUser = await getCurrentUser();
  let distanceLabel = profile.location;
  if (
    currentUser?.latitude != null &&
    currentUser?.longitude != null &&
    profile.latitude != null &&
    profile.longitude != null
  ) {
    const km = distanceKm(
      currentUser.latitude,
      currentUser.longitude,
      profile.latitude,
      profile.longitude
    );
    distanceLabel = formatDistance(km);
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      <header className="bg-white border-b border-gray-100 px-5 pt-8 pb-6">
        <Link href="/find-care" className="text-teal-600 text-sm font-medium mb-4 inline-block">
          ← Back to search
        </Link>
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center text-2xl font-bold shrink-0">
            {user.name.charAt(0)}
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">{user.name}</h1>
            <div className="text-sm text-teal-700 font-medium mt-0.5">{distanceLabel}</div>
            <div className="flex gap-1.5 mt-2 flex-wrap">
              {(profile.identityVerified || user.verified) && (
                <span className="badge-teal text-[10px]">Verified</span>
              )}
              <span className="badge-gray text-[10px] capitalize">{profile.priceType}</span>
            </div>
          </div>
        </div>
      </header>

      <div className="px-5 pt-5 space-y-4">
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-2xl font-bold text-gray-900">
                {profile.pricePerDay > 0 ? `€${profile.pricePerDay}` : 'Volunteer'}
              </div>
              <div className="text-xs text-gray-500">per day</div>
            </div>
            <div className="text-right">
              <div className="font-semibold">⭐ {profile.rating.toFixed(1)}</div>
              <div className="text-xs text-gray-500">
                {profile.reviewCount} reviews · {profile.completedBookings} stays
              </div>
            </div>
          </div>
          <div className="text-sm text-gray-600">
            Accepts:{' '}
            {[profile.acceptsDogs && 'Dogs', profile.acceptsCats && 'Cats']
              .filter(Boolean)
              .join(' & ')}{' '}
            · Max {profile.maxPets} pet{profile.maxPets > 1 ? 's' : ''}
          </div>
        </div>

        {profile.bio && (
          <div className="card">
            <h2 className="font-semibold text-gray-900 mb-2">About</h2>
            <p className="text-sm text-gray-600 leading-relaxed">{profile.bio}</p>
          </div>
        )}

        <div className="card">
          <h2 className="font-semibold text-gray-900 mb-2">Experience</h2>
          <p className="text-sm text-gray-600 leading-relaxed">{profile.experience}</p>
        </div>

        {profile.homeEnvironment && (
          <div className="card">
            <h2 className="font-semibold text-gray-900 mb-2">Home environment</h2>
            <p className="text-sm text-gray-600 leading-relaxed">{profile.homeEnvironment}</p>
          </div>
        )}

        <div className="card bg-gray-50">
          <p className="text-xs text-gray-500">
            Location shown is approximate only. Exact residential address is never shared publicly for privacy.
          </p>
        </div>

        {currentUser && currentUser.id !== user.id && (
          <Link
            href={`/care-requests/new?caregiver=${user.id}`}
            className="btn-primary w-full text-center block"
          >
            Request care from {user.name.split(' ')[0]}
          </Link>
        )}
      </div>
    </div>
  );
}
