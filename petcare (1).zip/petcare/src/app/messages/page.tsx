import Link from 'next/link';
import { getCurrentUser } from '@/lib/auth';
import { redirect } from 'next/navigation';

export default async function MessagesPage() {
  const user = await getCurrentUser();
  if (!user) redirect('/auth/login');

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-100 px-5 pt-8 pb-4">
        <h1 className="text-xl font-bold text-gray-900">Messages</h1>
      </header>
      <div className="px-5 pt-10 text-center">
        <div className="text-4xl mb-3">💬</div>
        <p className="text-gray-600 font-medium">No conversations yet</p>
        <p className="text-sm text-gray-500 mt-1 mb-6">
          Messages appear when you start a booking or receive an offer.
        </p>
        <Link href="/find-care" className="btn-primary">
          Find caregivers
        </Link>
      </div>
    </div>
  );
}
