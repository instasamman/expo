'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    city: '',
    isOwner: true,
    isCaregiver: false,
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function update(field: string, value: string | boolean) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.isOwner && !form.isCaregiver) {
      setError('Select at least one role');
      return;
    }
    setLoading(true);
    try {
      const roles: ('owner' | 'caregiver')[] = [];
      if (form.isOwner) roles.push('owner');
      if (form.isCaregiver) roles.push('caregiver');

      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          password: form.password,
          phone: form.phone || undefined,
          city: form.city || undefined,
          roles,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Registration failed');
        return;
      }
      router.push('/');
      router.refresh();
    } catch {
      setError('Something went wrong');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col px-5 pt-12 pb-24">
      <Link href="/" className="text-teal-600 text-sm font-medium mb-8">
        ← Back
      </Link>
      <h1 className="text-2xl font-bold text-gray-900 mb-2">Create account</h1>
      <p className="text-gray-500 mb-8">Join the PetCare community</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="label">Full name</label>
          <input
            className="input"
            value={form.name}
            onChange={(e) => update('name', e.target.value)}
            required
            placeholder="Your name"
          />
        </div>
        <div>
          <label className="label">Email</label>
          <input
            type="email"
            className="input"
            value={form.email}
            onChange={(e) => update('email', e.target.value)}
            required
            placeholder="you@example.com"
          />
        </div>
        <div>
          <label className="label">Password</label>
          <input
            type="password"
            className="input"
            value={form.password}
            onChange={(e) => update('password', e.target.value)}
            required
            minLength={6}
            placeholder="At least 6 characters"
          />
        </div>
        <div>
          <label className="label">Phone (optional)</label>
          <input
            className="input"
            value={form.phone}
            onChange={(e) => update('phone', e.target.value)}
            placeholder="+49 …"
          />
        </div>
        <div>
          <label className="label">City</label>
          <input
            className="input"
            value={form.city}
            onChange={(e) => update('city', e.target.value)}
            placeholder="Berlin"
          />
        </div>

        <div className="pt-2">
          <label className="label mb-3">I want to…</label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 bg-white cursor-pointer">
              <input
                type="checkbox"
                checked={form.isOwner}
                onChange={(e) => update('isOwner', e.target.checked)}
                className="w-5 h-5 rounded text-teal-600"
              />
              <div>
                <div className="font-medium text-sm">Find care for my pet</div>
                <div className="text-xs text-gray-500">I am a pet owner</div>
              </div>
            </label>
            <label className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 bg-white cursor-pointer">
              <input
                type="checkbox"
                checked={form.isCaregiver}
                onChange={(e) => update('isCaregiver', e.target.checked)}
                className="w-5 h-5 rounded text-teal-600"
              />
              <div>
                <div className="font-medium text-sm">Offer care</div>
                <div className="text-xs text-gray-500">I can look after dogs or cats</div>
              </div>
            </label>
          </div>
        </div>

        {error && (
          <div className="text-sm text-red-600 bg-red-50 rounded-xl px-4 py-3">{error}</div>
        )}
        <button type="submit" className="btn-primary w-full" disabled={loading}>
          {loading ? 'Creating account…' : 'Create account'}
        </button>
      </form>

      <p className="text-center text-sm text-gray-500 mt-8">
        Already have an account?{' '}
        <Link href="/auth/login" className="text-teal-600 font-semibold">
          Sign in
        </Link>
      </p>
    </div>
  );
}
