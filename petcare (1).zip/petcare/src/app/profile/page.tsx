import Link from 'next/link';
import { getCurrentUser } from '@/lib/auth';
import { getPetsByOwner, getCaregiverProfile, getDb } from '@/lib/db';
import { redirect } from 'next/navigation';
import LogoutButton from '@/components/LogoutButton';

export default async function ProfilePage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect('/auth/login');
  }

  const pets = await getPetsByOwner(user.id);
  const caregiverProfile = await getCaregiverProfile(user.id);
  const db = await getDb();
  const myRequests = db.careRequests.filter((r) => r.ownerId === user.id).length;
  const myBookings = db.bookings.filter(
    (b) => b.ownerId === user.id || b.caregiverId === user.id
  ).length;

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      <header className="bg-white border-b border-gray-100 px-5 pt-8 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center text-2xl font-bold">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">{user.name}</h1>
            <p className="text-sm text-gray-500">{user.email}</p>
            <div className="flex gap-1.5 mt-1.5 flex-wrap">
              {user.role.map((r) => (
                <span key={r} className="badge-teal capitalize text-[10px]">
                  {r}
                </span>
              ))}
              {user.verified && <span className="badge-green text-[10px]">Verified</span>}
            </div>
          </div>
        </div>
      </header>

      <div className="px-5 pt-5 space-y-4">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="card text-center py-3">
            <div className="text-lg font-bold text-gray-900">{pets.length}</div>
            <div className="text-xs text-gray-500">Pets</div>
          </div>
          <div className="card text-center py-3">
            <div className="text-lg font-bold text-gray-900">{myRequests}</div>
            <div className="text-xs text-gray-500">Requests</div>
          </div>
          <div className="card text-center py-3">
            <div className="text-lg font-bold text-gray-900">{myBookings}</div>
            <div className="text-xs text-gray-500">Bookings</div>
          </div>
        </div>

        {/* Pets */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold text-gray-900">My pets</h2>
            <Link href="/profile/pets/new" className="text-sm font-semibold text-teal-600">
              + Add pet
            </Link>
          </div>
          {pets.length === 0 ? (
            <div className="card text-center text-sm text-gray-500 py-6">
              No pets yet. Add your first pet to create care requests.
            </div>
          ) : (
            <div className="space-y-2">
              {pets.map((p) => (
                <div key={p.id} className="card flex items-center gap-3">
                  <div className="text-2xl">{p.type === 'dog' ? '🐕' : '🐈'}</div>
                  <div>
                    <div className="font-semibold">{p.name}</div>
                    <div className="text-xs text-gray-500">
                      {p.breed} · {p.age} yrs · {p.gender}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Caregiver profile */}
        {user.role.includes('caregiver') && (
          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-bold text-gray-900">Caregiver profile</h2>
              <Link href="/offer-care" className="text-sm font-semibold text-teal-600">
                {caregiverProfile ? 'Edit' : 'Set up'}
              </Link>
            </div>
            {caregiverProfile ? (
              <div className="card">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium capitalize">{caregiverProfile.priceType} care</div>
                    <div className="text-sm text-gray-500">
                      {caregiverProfile.pricePerDay
                        ? `€${caregiverProfile.pricePerDay}/day`
                        : 'Volunteer'}
                    </div>
                  </div>
                  <div className="text-right text-sm">
                    <div>⭐ {caregiverProfile.rating.toFixed(1)}</div>
                    <div className="text-xs text-gray-500">
                      {caregiverProfile.completedBookings} stays
                    </div>
                  </div>
                </div>
                <div className="text-xs text-gray-500 mt-2">
                  📍 {caregiverProfile.location} (approx.)
                </div>
              </div>
            ) : (
              <div className="card text-sm text-gray-500">
                Complete your caregiver profile to receive requests.
              </div>
            )}
          </section>
        )}

        {/* Links */}
        <section className="space-y-2 pt-2">
          <Link href="/bookings" className="card flex items-center justify-between">
            <span>My bookings</span>
            <span className="text-gray-400">→</span>
          </Link>
          <Link href="/messages" className="card flex items-center justify-between">
            <span>Messages</span>
            <span className="text-gray-400">→</span>
          </Link>
          {user.role.includes('admin') && (
            <Link href="/admin" className="card flex items-center justify-between bg-teal-50 border-teal-100">
              <span className="font-medium text-teal-800">Admin dashboard</span>
              <span className="text-teal-600">→</span>
            </Link>
          )}
          <LogoutButton />
        </section>
      </div>
    </div>
  );
}
