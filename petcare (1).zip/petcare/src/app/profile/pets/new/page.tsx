'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function NewPetPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    name: '',
    type: 'dog' as 'dog' | 'cat',
    age: '',
    breed: '',
    gender: 'unknown' as 'male' | 'female' | 'unknown',
    medicalInfo: '',
    behaviourInfo: '',
    foodInstructions: '',
    specialInstructions: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function update(field: string, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/pets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          age: Number(form.age),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Failed to add pet');
        return;
      }
      router.push('/profile');
      router.refresh();
    } catch {
      setError('Something went wrong');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 px-5 pt-8 pb-24">
      <Link href="/profile" className="text-teal-600 text-sm font-medium mb-6 inline-block">
        ← Back
      </Link>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Add a pet</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="label">Name</label>
          <input
            className="input"
            value={form.name}
            onChange={(e) => update('name', e.target.value)}
            required
            placeholder="Luna"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Type</label>
            <select
              className="input"
              value={form.type}
              onChange={(e) => update('type', e.target.value)}
            >
              <option value="dog">Dog</option>
              <option value="cat">Cat</option>
            </select>
          </div>
          <div>
            <label className="label">Age (years)</label>
            <input
              type="number"
              min="0"
              max="30"
              className="input"
              value={form.age}
              onChange={(e) => update('age', e.target.value)}
              required
            />
          </div>
        </div>
        <div>
          <label className="label">Breed</label>
          <input
            className="input"
            value={form.breed}
            onChange={(e) => update('breed', e.target.value)}
            required
            placeholder="Labrador Mix"
          />
        </div>
        <div>
          <label className="label">Gender</label>
          <select
            className="input"
            value={form.gender}
            onChange={(e) => update('gender', e.target.value)}
          >
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="unknown">Unknown</option>
          </select>
        </div>
        <div>
          <label className="label">Medical / health information</label>
          <textarea
            className="input min-h-[80px]"
            value={form.medicalInfo}
            onChange={(e) => update('medicalInfo', e.target.value)}
            placeholder="Vaccinations, conditions, allergies…"
          />
        </div>
        <div>
          <label className="label">Behaviour information</label>
          <textarea
            className="input min-h-[80px]"
            value={form.behaviourInfo}
            onChange={(e) => update('behaviourInfo', e.target.value)}
            placeholder="Friendly with other pets? Needs walks?…"
          />
        </div>
        <div>
          <label className="label">Food instructions</label>
          <textarea
            className="input min-h-[80px]"
            value={form.foodInstructions}
            onChange={(e) => update('foodInstructions', e.target.value)}
            placeholder="What, when and how much to feed. Owner provides the food."
          />
        </div>
        <div>
          <label className="label">Special instructions</label>
          <textarea
            className="input min-h-[80px]"
            value={form.specialInstructions}
            onChange={(e) => update('specialInstructions', e.target.value)}
            placeholder="Medication, routines, preferences…"
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 bg-red-50 rounded-xl px-4 py-3">{error}</div>
        )}
        <button type="submit" className="btn-primary w-full" disabled={loading}>
          {loading ? 'Saving…' : 'Save pet'}
        </button>
      </form>
    </div>
  );
}
