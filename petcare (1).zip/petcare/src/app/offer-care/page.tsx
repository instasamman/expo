'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function OfferCarePage() {
  const router = useRouter();
  const [form, setForm] = useState({
    bio: '',
    experience: '',
    acceptsDogs: true,
    acceptsCats: true,
    maxPets: 1,
    homeEnvironment: '',
    priceType: 'lowcost' as 'volunteer' | 'lowcost' | 'professional',
    pricePerDay: 20,
    city: 'Berlin',
    location: '',
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [existing, setExisting] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch('/api/caregiver-profile');
        if (res.status === 401) {
          router.push('/auth/login');
          return;
        }
        const data = await res.json();
        if (data.profile) {
          setExisting(true);
          setForm({
            bio: data.profile.bio || '',
            experience: data.profile.experience || '',
            acceptsDogs: data.profile.acceptsDogs,
            acceptsCats: data.profile.acceptsCats,
            maxPets: data.profile.maxPets,
            homeEnvironment: data.profile.homeEnvironment || '',
            priceType: data.profile.priceType,
            pricePerDay: data.profile.pricePerDay || 0,
            city: data.profile.city || 'Berlin',
            location: data.profile.location || '',
          });
        }
      } catch {
        // ignore
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [router]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSaving(true);
    try {
      const res = await fetch('/api/caregiver-profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Failed to save');
        return;
      }
      router.push('/profile');
      router.refresh();
    } catch {
      setError('Something went wrong');
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <div className="p-8 text-center text-gray-500">Loading…</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 px-5 pt-8 pb-24">
      <Link href="/profile" className="text-teal-600 text-sm font-medium mb-6 inline-block">
        ← Back
      </Link>
      <h1 className="text-2xl font-bold text-gray-900 mb-2">
        {existing ? 'Edit caregiver profile' : 'Become a caregiver'}
      </h1>
      <p className="text-gray-500 text-sm mb-6">
        Set your preferences. Your exact address is never shown publicly — only approximate distance.
      </p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="label">Bio</label>
          <textarea
            className="input min-h-[90px]"
            value={form.bio}
            onChange={(e) => setForm({ ...form, bio: e.target.value })}
            placeholder="Tell pet owners about yourself…"
          />
        </div>
        <div>
          <label className="label">Experience with animals</label>
          <textarea
            className="input min-h-[80px]"
            value={form.experience}
            onChange={(e) => setForm({ ...form, experience: e.target.value })}
            required
            placeholder="Years of experience, previous pet sitting…"
          />
        </div>
        <div>
          <label className="label">Home environment</label>
          <textarea
            className="input min-h-[70px]"
            value={form.homeEnvironment}
            onChange={(e) => setForm({ ...form, homeEnvironment: e.target.value })}
            placeholder="Apartment, garden, other pets…"
          />
        </div>

        <div className="flex gap-4">
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.acceptsDogs}
              onChange={(e) => setForm({ ...form, acceptsDogs: e.target.checked })}
            />
            Accept dogs
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.acceptsCats}
              onChange={(e) => setForm({ ...form, acceptsCats: e.target.checked })}
            />
            Accept cats
          </label>
        </div>

        <div>
          <label className="label">Maximum number of pets</label>
          <input
            type="number"
            min="1"
            max="10"
            className="input"
            value={form.maxPets}
            onChange={(e) => setForm({ ...form, maxPets: Number(e.target.value) })}
          />
        </div>

        <div>
          <label className="label">Care type</label>
          <select
            className="input"
            value={form.priceType}
            onChange={(e) =>
              setForm({
                ...form,
                priceType: e.target.value as 'volunteer' | 'lowcost' | 'professional',
                pricePerDay: e.target.value === 'volunteer' ? 0 : form.pricePerDay || 20,
              })
            }
          >
            <option value="volunteer">Volunteer (no payment)</option>
            <option value="lowcost">Low-cost</option>
            <option value="professional">Professional</option>
          </select>
        </div>

        {form.priceType !== 'volunteer' && (
          <div>
            <label className="label">Price per day (€)</label>
            <input
              type="number"
              min="1"
              className="input"
              value={form.pricePerDay}
              onChange={(e) => setForm({ ...form, pricePerDay: Number(e.target.value) })}
            />
          </div>
        )}

        <div>
          <label className="label">City / area</label>
          <input
            className="input"
            value={form.city}
            onChange={(e) => setForm({ ...form, city: e.target.value })}
            required
            placeholder="Berlin"
          />
        </div>
        <div>
          <label className="label">Public location label</label>
          <input
            className="input"
            value={form.location}
            onChange={(e) => setForm({ ...form, location: e.target.value })}
            placeholder="Berlin Kreuzberg (approx. area only)"
          />
          <p className="text-xs text-gray-500 mt-1">
            Shown to owners. Exact address is private.
          </p>
        </div>

        {error && (
          <div className="text-sm text-red-600 bg-red-50 rounded-xl px-4 py-3">{error}</div>
        )}
        <button type="submit" className="btn-primary w-full" disabled={saving}>
          {saving ? 'Saving…' : existing ? 'Update profile' : 'Create profile'}
        </button>
      </form>
    </div>
  );
}
