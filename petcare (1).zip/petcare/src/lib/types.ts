// PetCare Core Types

export type UserRole = 'owner' | 'caregiver' | 'vet' | 'service' | 'admin';

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  name: string;
  phone?: string;
  role: UserRole[];
  avatarUrl?: string;
  location?: string;
  city?: string;
  latitude?: number;
  longitude?: number;
  verified: boolean;
  verificationStatus: 'none' | 'pending' | 'verified' | 'rejected';
  createdAt: string;
  updatedAt: string;
  emergencyContact?: string;
  emergencyPhone?: string;
}

export interface Pet {
  id: string;
  ownerId: string;
  name: string;
  type: 'dog' | 'cat';
  age: number;
  breed: string;
  gender: 'male' | 'female' | 'unknown';
  medicalInfo?: string;
  behaviourInfo?: string;
  foodInstructions?: string;
  specialInstructions?: string;
  photoUrl?: string;
  gpsDeviceId?: string;
  createdAt: string;
}

export interface CaregiverProfile {
  id: string;
  userId: string;
  bio?: string;
  experience: string;
  acceptsDogs: boolean;
  acceptsCats: boolean;
  maxPets: number;
  homeEnvironment?: string;
  priceType: 'volunteer' | 'lowcost' | 'professional';
  pricePerDay?: number;
  currency: string;
  availability: string[]; // ISO dates or ranges
  rating: number;
  reviewCount: number;
  completedBookings: number;
  identityVerified: boolean;
  profilePhoto?: string;
  location: string; // public display label, e.g. "Berlin Kreuzberg"
  city: string;
  latitude?: number; // approximate for distance calc only
  longitude?: number;
  locationVisibility: 'approximate' | 'city_only';
  searchRadiusKm?: number; // max distance caregiver is willing to travel / accept
  createdAt: string;
}

export interface CareRequest {
  id: string;
  ownerId: string;
  petId: string;
  startDate: string;
  endDate: string;
  location: string;
  city: string;
  latitude?: number;
  longitude?: number;
  searchRadiusKm: number; // 5 | 10 | 25 | 50 | 0 (any)
  specialInstructions?: string;
  status: 'open' | 'offered' | 'booked' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface CareOffer {
  id: string;
  careRequestId: string;
  caregiverId: string;
  message?: string;
  pricePerDay: number;
  priceType: 'volunteer' | 'lowcost' | 'professional';
  status: 'pending' | 'accepted' | 'rejected' | 'withdrawn';
  createdAt: string;
}

export interface Booking {
  id: string;
  careRequestId: string;
  careOfferId: string;
  ownerId: string;
  caregiverId: string;
  petId: string;
  startDate: string;
  endDate: string;
  agreedPrice: number;
  priceType: string;
  status: 'pending_agreement' | 'active' | 'completed' | 'cancelled';
  agreementId?: string;
  createdAt: string;
  completedAt?: string;
}

export interface Agreement {
  id: string;
  bookingId: string;
  ownerAccepted: boolean;
  caregiverAccepted: boolean;
  ownerAcceptedAt?: string;
  caregiverAcceptedAt?: string;
  content: string; // snapshot of terms
  responsibilitiesOwner: string;
  responsibilitiesCaregiver: string;
  healthInfo: string;
  feedingInstructions: string;
  medicationInstructions?: string;
  emergencyInstructions: string;
  veterinaryContact?: string;
  cancellationRules: string;
  gpsTracking: boolean;
  agreedPrice: number;
  startDate: string;
  endDate: string;
  createdAt: string;
}

export interface Review {
  id: string;
  bookingId: string;
  fromUserId: string;
  toUserId: string;
  rating: number;
  comment?: string;
  createdAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  receiverId: string;
  content: string;
  read: boolean;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: string;
  title: string;
  body: string;
  data?: Record<string, string>;
  read: boolean;
  createdAt: string;
}

export interface VeterinaryClinic {
  id: string;
  userId?: string;
  name: string;
  doctorName?: string;
  address: string;
  city: string;
  phone: string;
  openingHours: string;
  emergencyAvailable: boolean;
  services: string[];
  website?: string;
  verified: boolean;
  latitude?: number;
  longitude?: number;
  referralCode: string;
  createdAt: string;
}

export interface ServiceProvider {
  id: string;
  userId: string;
  businessName: string;
  category: 'grooming' | 'washing' | 'cleaning' | 'transport' | 'training' | 'veterinary' | 'other';
  description: string;
  location: string;
  city: string;
  priceRange?: string;
  rating: number;
  verified: boolean;
  createdAt: string;
}

export interface Service {
  id: string;
  providerId: string;
  title: string;
  description: string;
  price: number;
  durationMinutes?: number;
}

export interface ServiceBooking {
  id: string;
  serviceId: string;
  ownerId: string;
  providerId: string;
  petId?: string;
  date: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  price: number;
  createdAt: string;
}

export interface GPSDevice {
  id: string;
  petId: string;
  provider: string;
  deviceId: string;
  lastLocation?: string;
  lastLat?: number;
  lastLng?: number;
  trackingStatus: 'active' | 'inactive' | 'unknown';
  updatedAt: string;
}

export interface EmergencyEvent {
  id: string;
  bookingId: string;
  triggeredBy: string;
  type: string;
  description?: string;
  location?: string;
  resolved: boolean;
  createdAt: string;
}

export interface Report {
  id: string;
  reporterId: string;
  reportedUserId: string;
  reason: string;
  details?: string;
  status: 'open' | 'reviewed' | 'resolved';
  createdAt: string;
}

export interface VerificationRequest {
  id: string;
  userId: string;
  type: 'identity' | 'profile' | 'clinic';
  documents?: string[];
  status: 'pending' | 'approved' | 'rejected';
  adminNote?: string;
  createdAt: string;
}

export interface ReferralRegistration {
  id: string;
  referralCode: string;
  clinicId: string;
  userId: string;
  createdAt: string;
}

export interface AdminSettings {
  id: string;
  serviceFeeOwnerPercent: number;
  serviceFeeCaregiverPercent: number;
  serviceFeeFixed: number;
  currency: string;
  termsAndConditions: string;
  agreementTemplate: string;
  platformName: string;
  supportEmail: string;
  updatedAt: string;
}

export interface Database {
  users: User[];
  pets: Pet[];
  caregiverProfiles: CaregiverProfile[];
  careRequests: CareRequest[];
  careOffers: CareOffer[];
  bookings: Booking[];
  agreements: Agreement[];
  reviews: Review[];
  messages: Message[];
  notifications: Notification[];
  veterinaryClinics: VeterinaryClinic[];
  serviceProviders: ServiceProvider[];
  services: Service[];
  serviceBookings: ServiceBooking[];
  gpsDevices: GPSDevice[];
  emergencyEvents: EmergencyEvent[];
  reports: Report[];
  verificationRequests: VerificationRequest[];
  referralRegistrations: ReferralRegistration[];
  adminSettings: AdminSettings[];
}
