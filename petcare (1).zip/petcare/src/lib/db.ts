import { promises as fs } from 'fs';
import path from 'path';
import { Database, User, Pet, CareRequest, CareOffer, Booking, Agreement, CaregiverProfile, Review, Message, Notification, VeterinaryClinic, AdminSettings } from './types';
import crypto from 'crypto';

const DB_PATH = path.join(process.cwd(), 'data', 'db.json');

const defaultSettings: AdminSettings = {
  id: 'settings-1',
  serviceFeeOwnerPercent: 10,
  serviceFeeCaregiverPercent: 5,
  serviceFeeFixed: 0,
  currency: 'EUR',
  termsAndConditions: `PetCare is a marketplace connecting pet owners with caregivers. PetCare does not provide care services itself and is not a party to the care agreement between owner and caregiver. All parties must comply with applicable local laws. Final legal wording of agreements must comply with the laws of the country where the service is provided. PetCare charges a transparent service fee as configured.`,
  agreementTemplate: `DIGITAL CARE AGREEMENT

This agreement is between the Pet Owner and the Caregiver for temporary care of the pet(s) listed.

1. RESPONSIBILITIES OF THE OWNER
- Provide accurate health, behaviour and feeding information.
- Provide the pet's normal food and clear feeding instructions.
- Ensure the pet is in suitable health for temporary care.
- Provide emergency contact and veterinary details.
- Agree to the start and end dates and the agreed price.

2. RESPONSIBILITIES OF THE CAREGIVER
- Provide care according to the instructions supplied by the owner.
- Follow feeding, medication and special instructions.
- Maintain a safe environment for the pet.
- Contact the owner and emergency contacts if issues arise.
- Return the pet in the same condition at the agreed end time.

3. PET HEALTH & FEEDING
[auto-filled from request]

4. EMERGENCY INSTRUCTIONS
[auto-filled]

5. VETERINARY CONTACT
[auto-filled]

6. PRICE & CANCELLATION
Agreed price and cancellation rules as discussed and accepted by both parties.

7. GPS TRACKING
Optional. Only if both parties agree and a compatible device is linked.

IMPORTANT: This is a private agreement between the parties. PetCare is a platform only and does not assume liability for the care provided. Parties should ensure the agreement complies with local laws.`,
  platformName: 'PetCare',
  supportEmail: 'support@petcare.app',
  updatedAt: new Date().toISOString(),
};

function createEmptyDb(): Database {
  return {
    users: [],
    pets: [],
    caregiverProfiles: [],
    careRequests: [],
    careOffers: [],
    bookings: [],
    agreements: [],
    reviews: [],
    messages: [],
    notifications: [],
    veterinaryClinics: [],
    serviceProviders: [],
    services: [],
    serviceBookings: [],
    gpsDevices: [],
    emergencyEvents: [],
    reports: [],
    verificationRequests: [],
    referralRegistrations: [],
    adminSettings: [defaultSettings],
  };
}

async function ensureDb(): Promise<Database> {
  try {
    await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
    const data = await fs.readFile(DB_PATH, 'utf-8');
    return JSON.parse(data) as Database;
  } catch {
    const db = createEmptyDb();
    // Seed admin and sample data
    const adminId = crypto.randomUUID();
    db.users.push({
      id: adminId,
      email: 'admin@petcare.app',
      passwordHash: hashPassword('admin123'),
      name: 'PetCare Admin',
      role: ['admin'],
      verified: true,
      verificationStatus: 'verified',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    // Sample owner
    const ownerId = crypto.randomUUID();
    db.users.push({
      id: ownerId,
      email: 'owner@example.com',
      passwordHash: hashPassword('owner123'),
      name: 'Anna Owner',
      phone: '+49123456789',
      role: ['owner'],
      location: 'Berlin Mitte',
      city: 'Berlin',
      latitude: 52.5208,
      longitude: 13.4094,
      verified: true,
      verificationStatus: 'verified',
      emergencyContact: 'Max Mustermann',
      emergencyPhone: '+49987654321',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    const petId = crypto.randomUUID();
    db.pets.push({
      id: petId,
      ownerId,
      name: 'Luna',
      type: 'dog',
      age: 3,
      breed: 'Labrador Mix',
      gender: 'female',
      medicalInfo: 'Vaccinated, no known allergies. Microchipped.',
      behaviourInfo: 'Friendly with people and other dogs. Needs daily walks.',
      foodInstructions: 'Dry food twice a day (morning & evening), 150g each. Fresh water always available.',
      specialInstructions: 'Loves toys. Sleeps in the living room.',
      createdAt: new Date().toISOString(),
    });

    // Sample caregiver
    const caregiverId = crypto.randomUUID();
    db.users.push({
      id: caregiverId,
      email: 'caregiver@example.com',
      passwordHash: hashPassword('care123'),
      name: 'Tom Caregiver',
      phone: '+49111222333',
      role: ['caregiver'],
      location: 'Berlin Kreuzberg',
      city: 'Berlin',
      latitude: 52.4987,
      longitude: 13.418,
      verified: true,
      verificationStatus: 'verified',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    db.caregiverProfiles.push({
      id: crypto.randomUUID(),
      userId: caregiverId,
      bio: 'Experienced dog lover with a quiet apartment and a small garden. Happy to take care of your pets while you travel.',
      experience: '5 years looking after friends\' dogs and cats. Previously volunteered at a local shelter.',
      acceptsDogs: true,
      acceptsCats: true,
      maxPets: 2,
      homeEnvironment: 'Apartment with balcony and nearby park. No other pets currently.',
      priceType: 'lowcost',
      pricePerDay: 25,
      currency: 'EUR',
      availability: [],
      rating: 4.8,
      reviewCount: 12,
      completedBookings: 15,
      identityVerified: true,
      location: 'Berlin Kreuzberg',
      city: 'Berlin',
      latitude: 52.4987,
      longitude: 13.418,
      locationVisibility: 'approximate',
      searchRadiusKm: 25,
      createdAt: new Date().toISOString(),
    });

    // Another caregiver - volunteer
    const volId = crypto.randomUUID();
    db.users.push({
      id: volId,
      email: 'volunteer@example.com',
      passwordHash: hashPassword('vol123'),
      name: 'Sara Volunteer',
      role: ['caregiver'],
      location: 'Berlin Prenzlauer Berg',
      city: 'Berlin',
      latitude: 52.5388,
      longitude: 13.4244,
      verified: true,
      verificationStatus: 'verified',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    db.caregiverProfiles.push({
      id: crypto.randomUUID(),
      userId: volId,
      bio: 'Pet lover offering volunteer care for short trips. I work from home and can give lots of attention.',
      experience: 'Lifelong pet owner. Two years of occasional pet sitting.',
      acceptsDogs: true,
      acceptsCats: true,
      maxPets: 1,
      homeEnvironment: 'Quiet apartment, no other animals.',
      priceType: 'volunteer',
      pricePerDay: 0,
      currency: 'EUR',
      availability: [],
      rating: 5.0,
      reviewCount: 4,
      completedBookings: 6,
      identityVerified: true,
      location: 'Berlin Prenzlauer Berg',
      city: 'Berlin',
      latitude: 52.5388,
      longitude: 13.4244,
      locationVisibility: 'approximate',
      searchRadiusKm: 15,
      createdAt: new Date().toISOString(),
    });

    // Extra caregivers for distance demo
    const michaelId = crypto.randomUUID();
    db.users.push({
      id: michaelId,
      email: 'michael@example.com',
      passwordHash: hashPassword('care123'),
      name: 'Michael',
      role: ['caregiver'],
      location: 'Berlin Charlottenburg',
      city: 'Berlin',
      latitude: 52.5166,
      longitude: 13.3041,
      verified: true,
      verificationStatus: 'verified',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    db.caregiverProfiles.push({
      id: crypto.randomUUID(),
      userId: michaelId,
      bio: 'Professional pet sitter with years of experience.',
      experience: '8 years professional pet sitting',
      acceptsDogs: true,
      acceptsCats: false,
      maxPets: 3,
      homeEnvironment: 'House with garden',
      priceType: 'professional',
      pricePerDay: 40,
      currency: 'EUR',
      availability: [],
      rating: 4.9,
      reviewCount: 28,
      completedBookings: 40,
      identityVerified: true,
      location: 'Berlin Charlottenburg',
      city: 'Berlin',
      latitude: 52.5166,
      longitude: 13.3041,
      locationVisibility: 'approximate',
      searchRadiusKm: 30,
      createdAt: new Date().toISOString(),
    });

    // Sample vet clinic
    const clinicId = crypto.randomUUID();
    db.veterinaryClinics.push({
      id: clinicId,
      name: 'Tierklinik Berlin Mitte',
      doctorName: 'Dr. Eva Schmidt',
      address: 'Friedrichstraße 123, 10117 Berlin',
      city: 'Berlin',
      phone: '+49301234567',
      openingHours: 'Mon-Fri 08:00-18:00, Sat 09:00-13:00',
      emergencyAvailable: true,
      services: ['General check-up', 'Vaccinations', 'Surgery', 'Emergency care', 'Dental'],
      website: 'https://example-vet.de',
      verified: true,
      referralCode: 'VET-BERLIN-001',
      createdAt: new Date().toISOString(),
    });

    await saveDb(db);
    return db;
  }
}

export async function getDb(): Promise<Database> {
  return ensureDb();
}

export async function saveDb(db: Database): Promise<void> {
  await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
  await fs.writeFile(DB_PATH, JSON.stringify(db, null, 2), 'utf-8');
}

export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + 'petcare-salt').digest('hex');
}

export function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

export function generateId(): string {
  return crypto.randomUUID();
}

// Helper queries
export async function findUserByEmail(email: string): Promise<User | undefined> {
  const db = await getDb();
  return db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
}

export async function findUserById(id: string): Promise<User | undefined> {
  const db = await getDb();
  return db.users.find(u => u.id === id);
}

export async function getCaregiverProfile(userId: string): Promise<CaregiverProfile | undefined> {
  const db = await getDb();
  return db.caregiverProfiles.find(p => p.userId === userId);
}

export async function getPetsByOwner(ownerId: string): Promise<Pet[]> {
  const db = await getDb();
  return db.pets.filter(p => p.ownerId === ownerId);
}

export async function getOpenCareRequests(city?: string): Promise<CareRequest[]> {
  const db = await getDb();
  let requests = db.careRequests.filter(r => r.status === 'open' || r.status === 'offered');
  if (city) {
    requests = requests.filter(r => r.city.toLowerCase().includes(city.toLowerCase()));
  }
  return requests;
}

export async function createNotification(userId: string, type: string, title: string, body: string, data?: Record<string, string>) {
  const db = await getDb();
  const notif: Notification = {
    id: generateId(),
    userId,
    type,
    title,
    body,
    data,
    read: false,
    createdAt: new Date().toISOString(),
  };
  db.notifications.unshift(notif);
  await saveDb(db);
  return notif;
}

/** Haversine distance in km between two points. Server-side only. */
export function distanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth radius km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10; // 1 decimal place
}

export function formatDistance(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)} m away`;
  return `${km} km away`;
}

/** Approximate city coordinates for demo (Berlin areas) */
export const CITY_COORDS: Record<string, { lat: number; lng: number }> = {
  Berlin: { lat: 52.52, lng: 13.405 },
  'Berlin Mitte': { lat: 52.5208, lng: 13.4094 },
  'Berlin Kreuzberg': { lat: 52.4987, lng: 13.418 },
  'Berlin Prenzlauer Berg': { lat: 52.5388, lng: 13.4244 },
  'Berlin Charlottenburg': { lat: 52.5166, lng: 13.3041 },
  Munich: { lat: 48.1351, lng: 11.582 },
  Hamburg: { lat: 53.5511, lng: 9.9937 },
};

export function approxCoordsForCity(city: string): { lat: number; lng: number } | null {
  const key = Object.keys(CITY_COORDS).find(
    (k) => k.toLowerCase() === city.toLowerCase() || city.toLowerCase().includes(k.toLowerCase())
  );
  return key ? CITY_COORDS[key] : null;
}
