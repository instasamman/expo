import { cookies } from 'next/headers';
import { findUserById, findUserByEmail, verifyPassword, getDb, saveDb, generateId, hashPassword } from './db';
import { User } from './types';

const SESSION_COOKIE = 'petcare_session';

export async function getSession(): Promise<{ userId: string } | null> {
  const cookieStore = await cookies();
  const session = cookieStore.get(SESSION_COOKIE);
  if (!session?.value) return null;
  try {
    const data = JSON.parse(Buffer.from(session.value, 'base64').toString('utf-8'));
    if (data.userId && data.exp > Date.now()) {
      return { userId: data.userId };
    }
  } catch {
    return null;
  }
  return null;
}

export async function getCurrentUser(): Promise<User | null> {
  const session = await getSession();
  if (!session) return null;
  return (await findUserById(session.userId)) || null;
}

export async function login(email: string, password: string): Promise<{ success: boolean; error?: string; user?: User }> {
  const user = await findUserByEmail(email);
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return { success: false, error: 'Invalid email or password' };
  }
  const cookieStore = await cookies();
  const payload = Buffer.from(JSON.stringify({
    userId: user.id,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
  })).toString('base64');
  cookieStore.set(SESSION_COOKIE, payload, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60,
    path: '/',
  });
  return { success: true, user };
}

export async function logout() {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE);
}

export async function register(data: {
  email: string;
  password: string;
  name: string;
  phone?: string;
  city?: string;
  roles: ('owner' | 'caregiver')[];
}): Promise<{ success: boolean; error?: string; user?: User }> {
  const existing = await findUserByEmail(data.email);
  if (existing) {
    return { success: false, error: 'Email already registered' };
  }
  if (data.password.length < 6) {
    return { success: false, error: 'Password must be at least 6 characters' };
  }
  const db = await getDb();
  const user: User = {
    id: generateId(),
    email: data.email.toLowerCase(),
    passwordHash: hashPassword(data.password),
    name: data.name,
    phone: data.phone,
    role: data.roles,
    city: data.city,
    location: data.city,
    verified: false,
    verificationStatus: 'none',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  db.users.push(user);
  await saveDb(db);

  // Auto login
  const cookieStore = await cookies();
  const payload = Buffer.from(JSON.stringify({
    userId: user.id,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000,
  })).toString('base64');
  cookieStore.set(SESSION_COOKIE, payload, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60,
    path: '/',
  });

  return { success: true, user };
}

export function requireAuth(user: User | null): asserts user is User {
  if (!user) {
    throw new Error('Unauthorized');
  }
}

export function requireAdmin(user: User | null): asserts user is User {
  if (!user || !user.role.includes('admin')) {
    throw new Error('Admin access required');
  }
}
