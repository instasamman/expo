'use client';

import { Lang } from '@/lib/i18n';

export default function LanguageSwitcher({
  lang,
  onChange,
}: {
  lang: Lang;
  onChange: (l: Lang) => void;
}) {
  return (
    <div className="flex items-center rounded-full border border-gray-200 bg-white p-0.5 text-xs font-semibold">
      <button
        type="button"
        onClick={() => onChange('en')}
        className={`px-2.5 py-1 rounded-full transition ${
          lang === 'en' ? 'bg-teal-600 text-white' : 'text-gray-500'
        }`}
      >
        EN
      </button>
      <button
        type="button"
        onClick={() => onChange('ar')}
        className={`px-2.5 py-1 rounded-full transition ${
          lang === 'ar' ? 'bg-teal-600 text-white' : 'text-gray-500'
        }`}
      >
        عربي
      </button>
    </div>
  );
}
