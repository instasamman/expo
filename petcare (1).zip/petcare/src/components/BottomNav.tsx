'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { translations, Lang } from '@/lib/i18n';

const items = [
  { href: '/', key: 'home' as const, icon: '🏠' },
  { href: '/find-care', key: 'findCare' as const, icon: '🔍' },
  { href: '/services', key: 'services' as const, icon: '✂️' },
  { href: '/veterinarians', key: 'vets' as const, icon: '🏥' },
  { href: '/messages', key: 'messages' as const, icon: '💬' },
  { href: '/bookings', key: 'bookings' as const, icon: '📅' },
  { href: '/profile', key: 'profile' as const, icon: '👤' },
];

export default function BottomNav() {
  const pathname = usePathname();
  const [lang, setLang] = useState<Lang>('en');

  useEffect(() => {
    const saved = localStorage.getItem('petcare_lang') as Lang | null;
    if (saved === 'en' || saved === 'ar') setLang(saved);

    const onStorage = () => {
      const s = localStorage.getItem('petcare_lang') as Lang | null;
      if (s === 'en' || s === 'ar') setLang(s);
    };
    window.addEventListener('storage', onStorage);
    // Also poll lightly for same-tab changes
    const id = setInterval(onStorage, 800);
    return () => {
      window.removeEventListener('storage', onStorage);
      clearInterval(id);
    };
  }, []);

  if (pathname.startsWith('/auth') || pathname.startsWith('/admin')) {
    return null;
  }

  const t = translations[lang];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-100 safe-bottom">
      <div className="flex items-center justify-around h-16 max-w-lg mx-auto px-1">
        {items.map((item) => {
          const active =
            pathname === item.href ||
            (item.href !== '/' && pathname.startsWith(item.href));
          const label = t[item.key] || item.key;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center flex-1 h-full text-[10px] gap-0.5 transition-colors ${
                active ? 'text-teal-600 font-semibold' : 'text-gray-400'
              }`}
            >
              <span className="text-lg leading-none">{item.icon}</span>
              <span className="truncate max-w-[56px]">{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
